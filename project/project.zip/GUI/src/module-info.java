/**
 * 
 */
/**
 * @author Asus
 *
 */
module GUI {
	requires java.desktop;
}